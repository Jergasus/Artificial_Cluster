var searchData=
[
  ['alta_5fprioridad_84',['alta_prioridad',['../classArea__de__Espera.html#aaa40d44059fc33dc83b1cfd6d3411d26',1,'Area_de_Espera']]],
  ['alta_5fproceso_5fespera_85',['alta_proceso_espera',['../classArea__de__Espera.html#a9d2f3f61952be3df536e1cf18f7e6a19',1,'Area_de_Espera']]],
  ['alta_5fproceso_5fprocesador_86',['alta_proceso_procesador',['../classCluster.html#a5786b35aeee3dbdf3d03928e40949ab9',1,'Cluster']]],
  ['area_5fde_5fespera_87',['Area_de_Espera',['../classArea__de__Espera.html#a3231c321a9441f69a9e099827d4f3369',1,'Area_de_Espera']]],
  ['avanzar_5ftiempo_88',['avanzar_tiempo',['../classCluster.html#a3b93301a46cfa8cadf8d0121e234c386',1,'Cluster::avanzar_tiempo()'],['../classProcesador.html#aa13775c00d510ff83cccbe99bcf22c7b',1,'Procesador::avanzar_tiempo()'],['../classProceso.html#a5f58d98612c5a45afec0a2c88f75c88b',1,'Proceso::avanzar_tiempo()']]]
];

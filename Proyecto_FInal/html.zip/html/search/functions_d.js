var searchData=
[
  ['siguiente_5fproceso_127',['siguiente_proceso',['../classProcesador.html#afac6afed4b642260751ce48ff29e4d76',1,'Procesador']]]
];

var searchData=
[
  ['hueco_5fmin_107',['hueco_min',['../classProcesador.html#a45d2ba3ce2160cef60c8d38e10de8cfc',1,'Procesador']]]
];

var searchData=
[
  ['procesador_122',['Procesador',['../classProcesador.html#aacfa2a06c7d44636ecfb0338bebbfa8b',1,'Procesador']]],
  ['procesador_5fapto_123',['procesador_apto',['../classCluster.html#ae5c0f7b9da451abf36593586b728f4ab',1,'Cluster']]],
  ['proceso_124',['Proceso',['../classProceso.html#a632f57d6ec48e76c80fbeb7734c1148c',1,'Proceso::Proceso()'],['../classProceso.html#a8c0f4efcd62ce74daddbfc5401092ac6',1,'Proceso::Proceso(int ident, int mem, int time)']]]
];

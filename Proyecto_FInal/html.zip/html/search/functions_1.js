var searchData=
[
  ['baja_5fprioridad_89',['baja_prioridad',['../classArea__de__Espera.html#a2156fa78f97c93e773a693469c4798f6',1,'Area_de_Espera']]],
  ['baja_5fproceso_5fprocesador_90',['baja_proceso_procesador',['../classCluster.html#ad27c24f93d82a18964a7170c44c4d696',1,'Cluster']]]
];

var searchData=
[
  ['memoria_135',['memoria',['../classProcesador.html#af68811026d52327bbe7ff365f9dadf4a',1,'Procesador::memoria()'],['../classProceso.html#ac37ccb93a804abd4b829ac7d4ad828bd',1,'Proceso::memoria()']]]
];

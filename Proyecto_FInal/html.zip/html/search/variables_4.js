var searchData=
[
  ['ident_5fpos_133',['ident_pos',['../classProcesador.html#ae63ff989ed03396ea835a45048691b52',1,'Procesador']]],
  ['identificador_134',['identificador',['../classProcesador.html#ac9edc7bbfe8bc9f673e8b1517232c84b',1,'Procesador::identificador()'],['../classProceso.html#a3418ac65a7c31135ed436bb38add64dc',1,'Proceso::identificador()']]]
];

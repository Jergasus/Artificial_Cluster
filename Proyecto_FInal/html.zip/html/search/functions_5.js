var searchData=
[
  ['fallos_106',['fallos',['../program_8cc.html#a0badc15cdb18bf1e6f4ad7efd1c64df7',1,'program.cc']]]
];

var searchData=
[
  ['priority_82',['Priority',['../structArea__de__Espera_1_1Priority.html',1,'Area_de_Espera']]],
  ['procesador_83',['Procesador',['../classProcesador.html',1,'']]],
  ['proceso_84',['Proceso',['../classProceso.html',1,'']]]
];

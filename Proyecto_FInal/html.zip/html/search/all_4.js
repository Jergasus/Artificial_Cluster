var searchData=
[
  ['eliminar_5fproceso_27',['eliminar_proceso',['../classProcesador.html#a5ac51f563af83e2034fe4ca6fb852b70',1,'Procesador']]],
  ['enviar_5fprocesos_5fcluster_28',['enviar_procesos_cluster',['../classArea__de__Espera.html#ad5069a946201e9c6ffee0459046bf810',1,'Area_de_Espera']]],
  ['escribir_5fprocesos_29',['escribir_procesos',['../classProcesador.html#ac5711a702b26614e4f4ce4a89208ebce',1,'Procesador']]],
  ['espacio_5flibre_30',['espacio_libre',['../classProcesador.html#a5bb6540297ea713e5f583c4b82fe3c5b',1,'Procesador']]],
  ['espacio_5ftotal_31',['espacio_total',['../classProcesador.html#ad40c31687bfe9422ae0616279c3dd7ea',1,'Procesador']]],
  ['existe_5fproceso_32',['existe_proceso',['../classProcesador.html#a0333ef847a320533f897a2be6537c2e1',1,'Procesador']]]
];

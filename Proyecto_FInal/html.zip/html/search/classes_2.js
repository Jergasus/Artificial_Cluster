var searchData=
[
  ['prioridad_72',['Prioridad',['../structArea__de__Espera_1_1Prioridad.html',1,'Area_de_Espera']]],
  ['procesador_73',['Procesador',['../classProcesador.html',1,'']]],
  ['proceso_74',['Proceso',['../classProceso.html',1,'']]]
];

var searchData=
[
  ['no_5ftiene_5fprocesos_52',['no_tiene_procesos',['../classProcesador.html#ae53904793499c639ed6dab8b9c755e32',1,'Procesador']]]
];

var searchData=
[
  ['area_5fde_5fespera_128',['area_de_espera',['../classArea__de__Espera.html#a7f00ba793eb5aff69307aced2f4fc3e4',1,'Area_de_Espera']]]
];

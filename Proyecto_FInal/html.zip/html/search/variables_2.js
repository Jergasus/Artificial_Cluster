var searchData=
[
  ['espacio_5flibre_130',['espacio_libre',['../classProcesador.html#a5bb6540297ea713e5f583c4b82fe3c5b',1,'Procesador']]],
  ['espacio_5ftotal_131',['espacio_total',['../classProcesador.html#ad40c31687bfe9422ae0616279c3dd7ea',1,'Procesador']]]
];

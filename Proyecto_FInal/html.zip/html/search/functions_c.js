var searchData=
[
  ['recalcular_5fhuecos_125',['recalcular_huecos',['../classProcesador.html#a7d61172e89742173537030f1dd081581',1,'Procesador']]],
  ['recibir_5fproceso_126',['recibir_proceso',['../classCluster.html#a1bd67668284a97e72dad386f8de0a817',1,'Cluster']]]
];

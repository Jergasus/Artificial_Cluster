var searchData=
[
  ['huecos_132',['huecos',['../classProcesador.html#a4df6aff2b5cffc92889fa78a2665eec5',1,'Procesador']]]
];

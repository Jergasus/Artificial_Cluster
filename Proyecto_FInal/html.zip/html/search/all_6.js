var searchData=
[
  ['hueco_5fmin_34',['hueco_min',['../classProcesador.html#a45d2ba3ce2160cef60c8d38e10de8cfc',1,'Procesador']]],
  ['huecos_35',['huecos',['../classProcesador.html#a4df6aff2b5cffc92889fa78a2665eec5',1,'Procesador']]]
];

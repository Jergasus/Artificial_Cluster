var searchData=
[
  ['ident_5fpos_36',['ident_pos',['../classProcesador.html#ae63ff989ed03396ea835a45048691b52',1,'Procesador']]],
  ['identificador_37',['identificador',['../classProcesador.html#ac9edc7bbfe8bc9f673e8b1517232c84b',1,'Procesador::identificador()'],['../classProceso.html#a3418ac65a7c31135ed436bb38add64dc',1,'Proceso::identificador()']]],
  ['imprimir_38',['imprimir',['../classProceso.html#ac30da2d4218103a4bb7344483cecec89',1,'Proceso']]],
  ['imprimir_5farea_5fespera_39',['imprimir_area_espera',['../classArea__de__Espera.html#ac235074f6c395f17449f4fcb421fd20c',1,'Area_de_Espera']]],
  ['imprimir_5festructura_40',['imprimir_estructura',['../classCluster.html#aec96799cd68357767c81cb788cd4129b',1,'Cluster']]],
  ['imprimir_5festructura_5fcluster_41',['imprimir_estructura_cluster',['../classCluster.html#a948d7075f9b30c2885ce804029e5ab25',1,'Cluster']]],
  ['imprimir_5fprioridad_42',['imprimir_prioridad',['../classArea__de__Espera.html#ae83f2d06628bfee83b970760114f4a18',1,'Area_de_Espera']]],
  ['imprimir_5fprocesador_43',['imprimir_procesador',['../classCluster.html#a545cc70fcdb0857afb851069e63ea1de',1,'Cluster']]],
  ['imprimir_5fprocesadores_5fcluster_44',['imprimir_procesadores_cluster',['../classCluster.html#ab8a628286f8a977063ea4395d9a422bf',1,'Cluster']]],
  ['inicializar_45',['inicializar',['../classArea__de__Espera.html#ae9b3ade14202981ec8ce42c340ef768c',1,'Area_de_Espera::inicializar()'],['../classProcesador.html#a26af908b89b133a7eb2e75c445e86ab0',1,'Procesador::inicializar(const string &amp;ident, int mem)']]],
  ['introducir_5fproceso_46',['introducir_proceso',['../classProcesador.html#adb1107ef9381cba3488bf2add1383e62',1,'Procesador']]]
];

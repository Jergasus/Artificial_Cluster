var searchData=
[
  ['cabe_5fproceso_11',['cabe_proceso',['../classProcesador.html#ad2e27e01ac63b5f0eeceaf9e82614d20',1,'Procesador']]],
  ['cluster_12',['Cluster',['../classCluster.html',1,'']]],
  ['cluster_13',['cluster',['../classCluster.html#ae08e3aefc00841e4ae55c40876c85164',1,'Cluster']]],
  ['cluster_14',['Cluster',['../classCluster.html#aee7feb1d599d4c8fda6c3ee83e86ba81',1,'Cluster']]],
  ['cluster_2ecc_15',['Cluster.cc',['../Cluster_8cc.html',1,'']]],
  ['cluster_2ehh_16',['Cluster.hh',['../Cluster_8hh.html',1,'']]],
  ['compactar_5fmemoria_17',['compactar_memoria',['../classProcesador.html#a06b0b1c913b359a1bc6c920120dd0e66',1,'Procesador']]],
  ['compactar_5fmemoria_5fcluster_18',['compactar_memoria_cluster',['../classCluster.html#a7b9ae511df4a6465f4e191df6564fd77',1,'Cluster']]],
  ['compactar_5fmemoria_5fprocesador_19',['compactar_memoria_procesador',['../classCluster.html#a5bedc8558ba975721788b52e7aaef629',1,'Cluster']]],
  ['configurar_5fcluster_20',['configurar_cluster',['../classCluster.html#a84f9daea57e2773ab5766ef82d2a1def',1,'Cluster']]],
  ['consultar_5fident_21',['consultar_ident',['../classProceso.html#aa16ca4c06da961d092a9a417f668ec14',1,'Proceso']]],
  ['consultar_5fidentificador_22',['consultar_identificador',['../classProcesador.html#a6f187762df047cfd7c69d8a0eeee8e49',1,'Procesador']]],
  ['consultar_5fmemoria_23',['consultar_memoria',['../classProcesador.html#ac54b06ae11bbccb3d5a9933c4cef0bbc',1,'Procesador::consultar_memoria()'],['../classProceso.html#a55976a19b8d909276c62e8be10036df5',1,'Proceso::consultar_memoria() const']]],
  ['consultar_5ftiempo_24',['consultar_tiempo',['../classProceso.html#a4816bee1b97d41126160494109f84c42',1,'Proceso']]]
];

var searchData=
[
  ['prioridad_53',['Prioridad',['../structArea__de__Espera_1_1Prioridad.html',1,'Area_de_Espera']]],
  ['procesador_54',['Procesador',['../classProcesador.html',1,'Procesador'],['../classProcesador.html#aacfa2a06c7d44636ecfb0338bebbfa8b',1,'Procesador::Procesador()']]],
  ['procesador_2ecc_55',['Procesador.cc',['../Procesador_8cc.html',1,'']]],
  ['procesador_2ehh_56',['Procesador.hh',['../Procesador_8hh.html',1,'']]],
  ['procesador_5fapto_57',['procesador_apto',['../classCluster.html#ae5c0f7b9da451abf36593586b728f4ab',1,'Cluster']]],
  ['procesadores_58',['Procesadores',['../classCluster.html#a4b590440ee951b692063c3306a0466df',1,'Cluster']]],
  ['proceso_59',['Proceso',['../classProceso.html',1,'Proceso'],['../classProceso.html#a632f57d6ec48e76c80fbeb7734c1148c',1,'Proceso::Proceso()'],['../classProceso.html#a8c0f4efcd62ce74daddbfc5401092ac6',1,'Proceso::Proceso(int ident, int mem, int time)']]],
  ['proceso_2ecc_60',['Proceso.cc',['../Proceso_8cc.html',1,'']]],
  ['proceso_2ehh_61',['Proceso.hh',['../Proceso_8hh.html',1,'']]],
  ['procesos_62',['procesos',['../structArea__de__Espera_1_1Prioridad.html#aad8c5753a0d3bc5c41ca590383829f55',1,'Area_de_Espera::Prioridad']]],
  ['procesos_5faceptados_63',['procesos_aceptados',['../structArea__de__Espera_1_1Prioridad.html#a2ddc618d3bb5648e6ef327db574314a7',1,'Area_de_Espera::Prioridad']]],
  ['procesos_5frechazados_64',['procesos_rechazados',['../structArea__de__Espera_1_1Prioridad.html#a86c6ab0813c438e7ccdc12afa1a9e2de',1,'Area_de_Espera::Prioridad']]],
  ['program_2ecc_65',['program.cc',['../program_8cc.html',1,'']]]
];

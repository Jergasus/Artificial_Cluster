var searchData=
[
  ['main_48',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['memoria_49',['memoria',['../classProcesador.html#af68811026d52327bbe7ff365f9dadf4a',1,'Procesador::memoria()'],['../classProceso.html#ac37ccb93a804abd4b829ac7d4ad828bd',1,'Proceso::memoria()']]],
  ['modificar_5fcluster_50',['modificar_cluster',['../classCluster.html#ae4f6cb37cfa684b90597ac04bfd36655',1,'Cluster']]],
  ['modificar_5fcluster_5faux_51',['modificar_cluster_aux',['../classCluster.html#a908f0c2be4d7c5210015a9d5802e5b85',1,'Cluster']]]
];

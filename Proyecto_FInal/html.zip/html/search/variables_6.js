var searchData=
[
  ['procesadores_136',['Procesadores',['../classCluster.html#a4b590440ee951b692063c3306a0466df',1,'Cluster']]],
  ['procesos_137',['procesos',['../structArea__de__Espera_1_1Prioridad.html#aad8c5753a0d3bc5c41ca590383829f55',1,'Area_de_Espera::Prioridad']]],
  ['procesos_5faceptados_138',['procesos_aceptados',['../structArea__de__Espera_1_1Prioridad.html#a2ddc618d3bb5648e6ef327db574314a7',1,'Area_de_Espera::Prioridad']]],
  ['procesos_5frechazados_139',['procesos_rechazados',['../structArea__de__Espera_1_1Prioridad.html#a86c6ab0813c438e7ccdc12afa1a9e2de',1,'Area_de_Espera::Prioridad']]]
];
